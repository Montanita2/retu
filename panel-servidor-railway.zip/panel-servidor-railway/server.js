
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const fs = require('fs');
const path = require('path');
const authMiddleware = require('./middleware');

const app = express();
app.use(cors());
app.use(cookieParser());
app.use(express.json());
app.use(express.static('public'));

let estado = 'Encendido';

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const users = JSON.parse(fs.readFileSync('./register.json', 'utf8'));
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    res.cookie('auth', 'logged_in');
    res.json({ success: true });
  } else {
    res.status(401).json({ error: 'Credenciales inválidas o no autorizado' });
  }
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('auth');
  res.json({ success: true });
});

app.get('/api/estado', authMiddleware, (req, res) => {
  res.json({ estado });
});

app.post('/api/encender', authMiddleware, (req, res) => {
  estado = 'Encendido';
  res.json({ estado });
});

app.post('/api/apagar', authMiddleware, (req, res) => {
  estado = 'Apagado';
  res.json({ estado });
});

app.post('/api/reiniciar', authMiddleware, (req, res) => {
  estado = 'Reiniciando...';
  setTimeout(() => { estado = 'Encendido'; }, 2000);
  res.json({ estado: 'Reiniciando...' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor activo en http://localhost:${PORT}`));
