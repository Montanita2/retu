
const cookieParser = require('cookie-parser');

function authMiddleware(req, res, next) {
  const { auth } = req.cookies;
  if (auth === 'logged_in') {
    next();
  } else {
    res.status(401).json({ error: 'No autorizado' });
  }
}

module.exports = authMiddleware;
