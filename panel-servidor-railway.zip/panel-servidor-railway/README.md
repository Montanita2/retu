# Panel Servidor Web

Este es un panel de control de servidor con autenticación segura por correo.

## 🚀 Desplegar en Railway

Haz clic aquí para desplegar este panel en Railway (requiere cuenta de GitHub):

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/new)

## ✍️ Cómo agregar usuarios

Edita el archivo `register.json` y agrega correos/autenticación así:

```json
[
  { "email": "admin@correo.com", "password": "admin123" }
]
```

